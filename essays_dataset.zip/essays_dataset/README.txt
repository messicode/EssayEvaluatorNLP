There are 100 essays contained in this folder. Each essay is answering one of six possible questions (prompts). Each essay is graded "low" if the essay was poorly written (50 such essays), or "high" if the essay was well written (50 such essays).

Contents:
1. "essays" contains 100 essays, each in its own text file.
2. "index.csv" maps each of the 100 essays from the "essays" folder to its corresponding prompt and grade it received.
